let count = 0;
let score = 0;
const scoreKeeper = document.getElementById("score");
scoreKeeper.innerText = score

function createShape(){
    count++;
     if (count > 5){
        count =1;
    }

    const square = document.createElement("div");
    square.classList.add("square")
    const circle = document.createElement("div");
    circle.classList.add("circle")
    

    square.style.left = Math.random()*95+"vw";
    square.style.animationDuration = Math.random()*0+5+"s";
    circle.style.left = Math.random()*95+"vw";
    circle.style.animationDuration = Math.random()*0+5+"s";

    square.innerText = count;

    let randomPercentage = Math.random()*100;
    /*console.log(randomPercentage)*/

    if (randomPercentage < 100) {document.body.appendChild(square);}
    else{document.body.appendChild(circle);}

    setTimeout(() => {
      square.remove();  
      circle.remove();
    }, 5000);

   const squares = document.querySelectorAll(".square");
   const circles = document.querySelectorAll(".circle");

   let nextScore = score + 1

    for (let i = 0; i < squares.length; i++){
        squares[i].addEventListener("click", () =>{
             /*alert("You clicked number " + (i+1))*/
             squares[i].classList.add("bye")
            
             if (score < nextScore){
             score = score + 1;
             console.log("CLicked")}
           
         
        });
    }

    
    for (let i = 0; i < circles.length; i++){
       circles[i].addEventListener("click", () =>{
             /*alert("You clicked number " + (i+1))*/
             circles[i].classList.add("bye")
             console.log("CLicked");
             score= score + 3;
    
         
        });
    }

   /*display the score*/
    
}
setInterval(createShape, 1000);

function displayScore(){
     scoreKeeper.innerText = score;
}

setInterval(displayScore, 100)
const btn=document.getElementById("btn");

btn.addEventListener("click", ()=>{
    document.body.style.background= bgChanger();

});

function bgChanger(){
    return `rgb( ${Math.floor(Math.random()*256)}, ${Math.floor(Math.random()*256)},${Math.floor(Math.random()*256)} )`
}
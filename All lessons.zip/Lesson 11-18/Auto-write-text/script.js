const txt="Welcome to my website. My name is Bob 👷";

let counter=0;

function autoWrite(){
    document.body.innerText = txt.slice(0, counter);

    counter++;

    if (counter > txt.length + 10){
        counter = 0;
    }
}

setInterval(autoWrite,90)

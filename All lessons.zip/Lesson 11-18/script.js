const button = document.getElementById("btn");
const navbar = document.getElementById("nav");
const jumbotron = document.getElementById("jumbotron");
const open=document.getElementById("open");
const close=document.getElementById("close");
const container=document.getElementById("container");
const txt = "Welcome to my website";
const text_container = document.getElementById("auto-text");
const imgs=document.getElementById("imgs");
const img=document.querySelectorAll("#imgs img");
let index=0;
const toggle = document.getElementById("toggle");

toggle.addEventListener("change", (e) =>{
    document.body.classList.toggle("dark", e.target.checked);
});

button.addEventListener("click", () => {
    button.classList.toggle("active");
    navbar.classList.toggle("active");
    jumbotron.classList.toggle("active");
});



open.addEventListener("click", ()=>{
    container.classList.add("active");
});

close.addEventListener("click", ()=>{
    container.classList.remove("active");
});

let counter=0;

function autoWrite(){
    text_container.innerText = txt.slice(0, counter);

    counter++;

    if (counter > txt.length + 10){
        counter = 1;
    }
}

setInterval(autoWrite,90)

function slideShow(){
    index++;

    if(index>img.length-1){
        index=0;
    }
    imgs.style.transform=`translateX(${index*-100}vw)`
}
setInterval(slideShow, 3000)

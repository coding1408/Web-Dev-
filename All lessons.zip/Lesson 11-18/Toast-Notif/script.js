const btn = document.getElementById("btn");
const cont = document.getElementById("container");

btn.addEventListener("click",()=>{
    createNote();
});

function createNote(){
    const notif = document.createElement("div");
    notif.classList.add("toast");

    notif.innerText="Bob ate Bobs Bob";

    cont.appendChild(notif);


    setTimeout(() => {
        notif.remove();
    }, 3000);
}
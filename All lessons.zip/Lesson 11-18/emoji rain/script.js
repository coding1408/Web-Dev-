function emojiRain(){
    var myArray=["⚽", "💢", "🍔", "✏️", "💀", "🎮","🎖️","🏅","🥉","🥈","🥇","🏆","🏐","🎾", "🥎","⚾","🏈","🏀","⚽","🎱","🏓","🎧","💰","⌨️","🖥️","💎","🤍","🤎","🖤","💜","💚","💙","💛","🧡","❤️","💵", "🤑", "💸"];
    var randomEmoji=myArray[Math.floor(Math.random()*myArray.length)];
    const emoji= document.createElement("div");
    emoji.classList.add("emoji");


    emoji.style.left=Math.random()*100+"vw";
    emoji.style.animationDuration = Math.random() *2 + 1 +'s';

    emoji.innerText=randomEmoji;

    document.body.appendChild(emoji);

    setTimeout(() => {
        emoji.remove();
    }, 4000);
}

setInterval(emojiRain, 100);
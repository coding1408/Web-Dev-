const imgs=document.getElementById("imgs");
const img=document.querySelectorAll("#imgs img");
let counter=0;

function slideShow(){
    counter++;

    if(counter>img.length-1){
        counter=0;
    }
    imgs.style.transform=`translateX(${counter*-500}px)`
}
setInterval(slideShow, 3000)